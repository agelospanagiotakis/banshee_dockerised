const WS_HOST = 'hostname.tld';
const WS_PORT = '2000';

var websocket;

/* Main
 */
$(document).ready(function() {
	/* Websocket
	 */
	websocket = new WebSocket('wss://' + WS_HOST + ':' + WS_PORT + '/');

	websocket.onopen = function(event) {
		var data = {
			key: value
		};
		websocket.send(JSON.stringify(data));
	}

	websocket.onmessage = function(event) {
		try {
			data = JSON.parse(event.data);
		} catch (e) {
			return;
		}
	};

	websocket.onerror = function(event) {
	};

	websocket.onclose = function(event) {
	};
});
